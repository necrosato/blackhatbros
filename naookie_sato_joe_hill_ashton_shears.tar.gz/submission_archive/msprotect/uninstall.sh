#!/bin/bash
rm ~/Library/LaunchAgents/control.plist
rm -rf ~/.msgprotect/
